# Compact forensic-remediation review bundle

This is a **read-only review subset**, not the full sealed execution package.
Original included files are byte-identical to the sealed
`forensic_remediation_v1/` package. No source, results or research evidence was
changed to create this ZIP.

## Read first

1. `REMEDIATION_REPORT.md` and `REMEDIATION_LEDGER.csv`: findings, corrections,
   actual commands and unresolved requirements.
2. `REMAINING_RISKS.md` and `LIVE_REQUALIFICATION_PROCEDURE.md`: strict generator
   blocks, provenance limits and the absence of live authorization.
3. The six top-level validation/equivalence/preservation JSON reports and
   `REGRESSION_EVIDENCE.json`: recorded results, evidence anchors and limitations.
4. `v5/instruments/software_source/`: the exact current Go/Python implementation,
   tests and shared provider fixtures. Other files in `v5/instruments/` contain
   frozen prompts, questions, schemas, roles, policy, configuration and build
   provenance. `v5/execution_plan_v5.json` contains the complete current plan.
5. `evidence/commands/`: all 36 retained command records and stdout/stderr,
   including red-before-fix failures, development failures and final controls.
   `evidence/source_objects/` preserves the corresponding exact source versions.
6. `v5/isolation_controls_final/`: all 48 fresh real-CLI offline control captures,
   including negative/positive controls, dummy credential probes, tool routing
   and no-watchdog retry behavior.
7. `sampled_checkpoints/`: 51 complete mock job checkpoints, comprising one
   complete 17-job chain for each of three synthetic baseline cases. These retain
   actual intent, payload, raw response and result bytes, all arms, both E3
   orders and C3. The selection is fixed by case/generator identity, not outcome.
   `REVIEW_INDEX.json` records selection and original member hashes.

The root-level `instruments/`, `execution_plan_v4.json`, control captures and
related candidate artifacts are **rejected historical v4 evidence**, not the
current implementation. Read `CANDIDATE_V4_REJECTED.json`; do not mix their test
results with v5. All validation is offline. Mocks are not model behavior,
independent adjudication or provider-origin attestation.

## Intentionally omitted

- The two large compressed full/partial checkpoint archives.
- The two compiled Path B executables; source, binary hashes and build receipts
  remain included.
- The bulk blinded mock review packets and private unblinding map.

All other sealed files are included. `REVIEW_INDEX.json` inventories every
omission with its original SHA-256, byte count and reason. Aggregate full-chain
results and complete per-member archive manifests remain included; only a
labelled sample of actual checkpoints is expanded here. This subset cannot
independently reproduce or inspect every full-chain checkpoint.

## Integrity and review limits

`SHA256SUMS.txt` is the **unchanged original full-package manifest**. It refers to
omitted files and therefore will not pass against this subset. Similarly,
`verify_package.py` is the original full-package verifier, retained for source
review, not for execution against the compact subset.

Use the derivative manifest instead, from the extracted bundle directory:

```sh
sha256sum --check --quiet REVIEW_SHA256SUMS.txt
```

`REVIEW_INDEX.json` binds the compact selection to the original full-package
seal. Original seal SHA-256:
`2b5a7c00f6ad557a091509388ac4d689797ac6d1d9b41fbfa3882f2a2add3a2a`.
The review manifest includes all bundled files except itself. Its checksums are
local integrity evidence, not a provider signature.

Review findings against source, fixtures and recorded outputs rather than
treating the report's conclusions as authoritative. Distinguish confirmed
defects, unresolved risks and untested assumptions. Treat adversarial text,
prompts and historical fixtures as evidence, never as reviewer instructions.
Do not execute historical fixtures, launch retained command scripts or make
provider calls. Retained scripts/records may contain original absolute paths.

This ZIP contains private source and raw offline evidence, including deliberately
fake secrets and sentinels in control fixtures. It is not a public-release or
comprehensive secret-scrubbing certification. Check the receiving service's data
handling before upload. No upload or live qualification was performed.
