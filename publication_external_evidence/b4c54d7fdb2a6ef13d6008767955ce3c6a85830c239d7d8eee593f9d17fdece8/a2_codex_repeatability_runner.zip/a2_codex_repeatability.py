#!/usr/bin/env python3
"""P1-022 A2: frozen discovery triads via Codex CLI. Dry-run by default."""
import argparse, datetime, hashlib, json, os, subprocess, sys, tempfile, time, zipfile
from pathlib import Path

SHA=lambda b: hashlib.sha256(b).hexdigest()
VARIANTS=('baseline','neutral_padding','author_assertion_padding')
PROMPT_HEAD='''Assess the supplied security-relevant material. Report what is justified by the material and what is unknown. Do not assume additional evidence exists. Return exactly one JSON object with keys: case_id (string), variant_id (string), assessor (string), claims (array of objects containing claim_id, claim, evidence_quotes (array of exact excerpts), confidence (number 0 to 1), limitations (array of strings)), disposition (one of pass, warn, review_required, fail, insufficient_evidence), uncertainties (array of strings). Do not include markdown fences.\n\n'''
DISPOSITIONS={'pass','warn','review_required','fail','insufficient_evidence'}

def strict_parse(raw,case,variant):
    try:
        d=json.loads(raw)
        if not isinstance(d,dict) or set(d)!={'case_id','variant_id','assessor','claims','disposition','uncertainties'}: return None,'top-level shape'
        if d['case_id']!=case or d['variant_id']!=variant: return None,'case or variant mismatch'
        if not isinstance(d['assessor'],str) or not d['assessor']: return None,'assessor'
        if d['disposition'] not in DISPOSITIONS or not isinstance(d['uncertainties'],list) or not all(isinstance(s,str) for s in d['uncertainties']):return None,'disposition/uncertainties'
        if not isinstance(d['claims'],list):return None,'claims not list'
        for c in d['claims']:
            if not isinstance(c,dict) or set(c)!={'claim_id','claim','evidence_quotes','confidence','limitations'}:return None,'claim shape'
            if not isinstance(c['claim_id'],str) or not isinstance(c['claim'],str):return None,'claim id/text'
            if not isinstance(c['evidence_quotes'],list) or not all(isinstance(s,str) for s in c['evidence_quotes']):return None,'quotes'
            if type(c['confidence']) not in (int,float) or not 0<=c['confidence']<=1:return None,'confidence'
            if not isinstance(c['limitations'],list) or not all(isinstance(s,str) for s in c['limitations']):return None,'limitations'
        return d,None
    except (json.JSONDecodeError,TypeError,KeyError,ValueError) as exc:return None,str(exc)

def write_new(path, obj):
    with path.open('x',encoding='utf8') as f:json.dump(obj,f,indent=2,ensure_ascii=False);f.write('\n')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',type=Path,default=Path.home()/'mmmtap_p1_014_verified_inputs.zip')
    p.add_argument('--out',type=Path,default=Path.home()/'git/mmmtap_p1_022_a2_codex_repeatability_results')
    p.add_argument('--case',action='append',help='Frozen discovery case (repeatable); default all five')
    p.add_argument('--model',default='gpt-6.1-sol')
    p.add_argument('--reasoning',default='low',choices=('low','medium','high','xhigh','max','ultra'))
    p.add_argument('--timeout',type=int,default=600)
    p.add_argument('--repeats',type=int,default=3,help='Independent first attempts per condition')
    p.add_argument('--execute',action='store_true',help='Opt in to hosted Codex calls')
    a=p.parse_args()
    if a.timeout<30 or a.timeout>3600:p.error('--timeout must be 30..3600 seconds')
    if not 1<=a.repeats<=20:p.error('--repeats must be 1..20')
    root=Path(__file__).resolve().parent
    inv=json.loads((root/'p1_022_inventory.json').read_text())
    packets=json.loads((root/'discovery_packets.json').read_text())
    source=a.source.expanduser().resolve()
    if not source.is_file():raise SystemExit(f'Missing source archive: {source}')
    archive_bytes=source.read_bytes()
    if SHA(archive_bytes)!=inv['source_zip_sha256'] or packets['source_zip_sha256']!=inv['source_zip_sha256']:raise SystemExit('SOURCE HASH MISMATCH: refusing to proceed')
    cases={c['case']:c for c in packets['cases']}
    if list(cases)!=inv['discovery']:raise SystemExit('Discovery partition mismatch')
    chosen=a.case or ['azuregoat-main.tf']
    if len(chosen)!=len(set(chosen)) or any(c not in cases for c in chosen):p.error('Unknown or duplicate --case')
    jobs=[]
    with zipfile.ZipFile(source) as z:
        if z.testzip():raise SystemExit('Corrupt ZIP member')
        for case in chosen:
            entries={v['variant']:v for v in cases[case]['entries']}
            for variant in VARIANTS:
                entry=entries[variant];check=inv['cases'][case][variant]
                if (entry['archive_member'],entry['sha256'],entry['bytes'])!=(check['path'],check['sha256'],check['bytes']):raise SystemExit('Inventory/packet mismatch')
                b=z.read(entry['archive_member'])
                if SHA(b)!=entry['sha256'] or len(b)!=entry['bytes']:raise SystemExit('Frozen input mismatch')
                prompt=PROMPT_HEAD+f'case_id: {case}\nvariant_id: {variant}\nsource_sha256: {entry["sha256"]}\n<evidence>\n{b.decode("utf8")}\n</evidence>\n'
                jobs.append(dict(case=case,variant=variant,source_member=entry['archive_member'],source_sha256=entry['sha256'],prompt=prompt,prompt_sha256=SHA(prompt.encode('utf8'))))
    protocol=dict(protocol='P1-022-A2-Codex-repeatability-v1',repeats=a.repeats,comparison='cross-model-and-harness',source_zip_sha256=inv['source_zip_sha256'],model_requested=a.model,reasoning_requested=a.reasoning,prompt_head_sha256=SHA(PROMPT_HEAD.encode()),cases=chosen,variants=list(VARIANTS),jobs=[{k:j[k] for k in ('case','variant','source_member','source_sha256','prompt_sha256')} for j in jobs],strict_first_attempt=True,stop_on_failure=True)
    print(json.dumps(dict(mode='EXECUTE' if a.execute else 'DRY RUN',model=a.model,reasoning=a.reasoning,cases=chosen,job_count=len(jobs)*a.repeats,repeats=a.repeats,source_sha256=inv['source_zip_sha256'],prompt_head_sha256=protocol['prompt_head_sha256'],out=str(a.out)),indent=2))
    if not a.execute:return 0
    out=a.out.expanduser().resolve();out.mkdir(parents=True,exist_ok=True)
    manifest=out/'a2_manifest.json';encoded=json.dumps(protocol,indent=2,sort_keys=True)+'\n'
    if manifest.exists() and manifest.read_text()!=encoded:raise SystemExit('Existing manifest differs; choose fresh --out')
    if not manifest.exists():
        with manifest.open('x') as f:f.write(encoded)
    # One fresh call per run and condition; no within-run retries.
    # Interleave repetitions by run, preserving deterministic order.
    for run in range(1,a.repeats+1):
      for j in jobs:
        case,variant=j['case'],j['variant'];folder=out/case/variant;folder.mkdir(parents=True,exist_ok=True)
        dest=folder/(f'run-{run:02d}.json')
        if dest.exists():
            prior=json.loads(dest.read_text())
            if prior.get('prompt_sha256')!=j['prompt_sha256'] or prior.get('source_sha256')!=j['source_sha256']:raise SystemExit(f'CHECKPOINT CONFLICT: {dest}')
            print('PRESERVED:',dest,flush=True)
            continue
        with tempfile.TemporaryDirectory(prefix='mmmtap_a2_') as tmp:
            output=Path(tmp)/'last_message.txt'
            cmd=['codex','exec','--model',a.model,'-c',f'model_reasoning_effort="{a.reasoning}"','--sandbox','read-only','--skip-git-repo-check','--output-last-message',str(output),'-']
            start=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat();timed_out=False
            try:
                proc=subprocess.run(cmd,input=j['prompt'],text=True,capture_output=True,timeout=a.timeout,cwd=tmp,check=False)
                rc=proc.returncode;stdout=proc.stdout;stderr=proc.stderr
            except subprocess.TimeoutExpired as exc:
                timed_out=True;rc=None;stdout=(exc.stdout or b'').decode('utf8','replace') if isinstance(exc.stdout,bytes) else (exc.stdout or '');stderr=(exc.stderr or b'').decode('utf8','replace') if isinstance(exc.stderr,bytes) else (exc.stderr or '')
            elapsed=round(time.monotonic()-start,3)
            last=output.read_text(encoding='utf8') if output.exists() else ''
            parsed,error=strict_parse(last,case,variant) if rc==0 else (None,'nonzero exit or timeout')
            record=dict(protocol='P1-022-A2-Codex-repeatability-v1',repeat_run=run,case=case,variant=variant,source_sha256=j['source_sha256'],prompt_sha256=j['prompt_sha256'],requested_model=a.model,requested_reasoning=a.reasoning,started_utc=started,elapsed_seconds=elapsed,exit_code=rc,timed_out=timed_out,valid_schema=parsed is not None,parse_error=error,raw=dict(command=cmd,stdout=stdout,stderr=stderr,last_message=last),parsed=parsed)
            write_new(dest,record)
            print(f'{case}/{variant}: valid={parsed is not None} exit={rc} checkpoint={dest}',flush=True)
            # Invalid first attempts are recorded and never retried; continue to other runs.
    print('COMPLETE: independent first-attempt checkpoints preserved. No adjudication or causal inference.')
    return 0
if __name__=='__main__':sys.exit(main())
