# MMMTAP Phase 2 — Corpus archive reconciler (v1)

This script performs **read-only evidence reconciliation**. It verifies all 135 declared primary corpus members byte-for-byte, checks archive hashes against the 44-record historical inventory, indexes ZIP member metadata and emits explicit unclassified states. It never executes content, calls a model, guesses membership, or assigns experiment eligibility.

Install `reconcile.py` alongside the Phase 2 manifests or run it anywhere. On Gaia:

```bash
python3 ~/git/mmmtap_phase2/MMMTAP_Phase2/reconcile.py \
  --plan-dir ~/git/mmmtap_phase2/MMMTAP_Phase2 \
  --corpus-zip ~/mmmtap_p1_014_verified_inputs.zip \
  --search-root ~/git \
  --search-root ~/ \
  --out ~/git/mmmtap_phase2/reconciliation_v1
```

Outputs: `SUMMARY.json`, `primary_inputs.csv`, `archive_registry.csv`, `archive_members.csv`, `discovered_zips.csv`, `SHA256SUMS.txt`.

**Interpretation:** `exact_sha_match` means archive identity was verified; it is *not* a statement of independent test-case eligibility. `not_located` is not proof an archive does not exist outside searched roots. `same_name_different_sha` is not automatically corruption, since historical copied ZIPs may differ. The next step must classify individual cases, not simply count ZIP files. Review all CSVs before deciding inclusion.

Scanning `~/` can take time and indexes ZIP central directories; ignore results from any changing output directories generated while the scan is running. The output directory is not used as an evidence input. Does not enumerate unzipped experiments.
